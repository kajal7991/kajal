-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2025 at 12:14 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orrsphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `orrs_admin`
--

CREATE TABLE `orrs_admin` (
  `admin_id` int(20) NOT NULL,
  `admin_fname` varchar(200) NOT NULL,
  `admin_lname` varchar(200) NOT NULL,
  `admin_email` varchar(200) NOT NULL,
  `admin_phone` varchar(15) NOT NULL,
  `admin_uname` varchar(200) NOT NULL,
  `admin_pwd` varchar(200) NOT NULL,
  `admin_dpic` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orrs_admin`
--

INSERT INTO `orrs_admin` (`admin_id`, `admin_fname`, `admin_lname`, `admin_email`, `admin_phone`, `admin_uname`, `admin_pwd`, `admin_dpic`) VALUES
(1, 'System ', 'Admin', 'admin@gmail.com', '0123456789', 'Administrator', '24e7b7d37fb084a8079033d6528894cdd06b63a2', 'admin-icn.png'),
(2, 'System', 'Admin', 'sameer123@gmail.com', '9876543210', 'Administrator', '24e7b7d37fb084a8079033d6528894cdd06b63a2', 'Screenshot (1).png');

-- --------------------------------------------------------

--
-- Table structure for table `orrs_employee`
--

CREATE TABLE `orrs_employee` (
  `emp_id` int(20) NOT NULL,
  `emp_fname` varchar(200) NOT NULL,
  `emp_lname` varchar(200) NOT NULL,
  `emp_nat_idno` varchar(200) NOT NULL,
  `emp_phone` varchar(200) NOT NULL,
  `emp_addr` varchar(200) NOT NULL,
  `emp_uname` varchar(200) NOT NULL,
  `emp_email` varchar(200) NOT NULL,
  `emp_pwd` varchar(200) NOT NULL,
  `emp_dpic` varchar(200) NOT NULL,
  `emp_dept` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orrs_employee`
--

INSERT INTO `orrs_employee` (`emp_id`, `emp_fname`, `emp_lname`, `emp_nat_idno`, `emp_phone`, `emp_addr`, `emp_uname`, `emp_email`, `emp_pwd`, `emp_dpic`, `emp_dept`) VALUES
(1011, 'vashu', 'gupta', '12345678', '1234567890', 'bhandup', 'vashu123', 'vashu123@gmail.com', '$2y$10$jturHAYv.T.NBa7LPq7uY.FP3t.N8sDuW21mPfpq2TyQdBVgMe0EC', '', 'booking'),
(1012, 'sameer', 'prajapati', '987654321', '7877722608', 'bhandup', 'sameer@123', 'sameer123@gmail.com', 'db0a50c5ddcd0a99ddd5214b88b5eff798661dd0', 'Screenshot (10).png', 'booking'),
(1017, 'aaro', 'gupta', '79918734', '1234567855', 'kanjur', 'aaro_g', 'aaro123@gmail.com', '24e7b7d37fb084a8079033d6528894cdd06b63a2', '', ''),
(1018, 'ham', 'gupta', '6464651', '8528528520', 'kanjur', 'ham', 'ham123@gmail.com', '$2y$10$JEfbAvAAAXeiFsE915uw3Os95XYiYamhiBiy0RFfiWHHeVZP67cZO', '', 'Indain'),
(1019, 'suman', 'prajapati', '123456789', '9639639630', 'kanjur', 'kajal_gupta', 'suman123@gmail.com', '$2y$10$shwh663eXrppaoOMEhnBJu7h.DlFkn4FiIlkzRUzFjP/qQnNYE3vq', '', 'Indain'),
(1020, 'deepa', 'gupta', '11111111', '5252525252', 'kanjur', 'deepa@123', 'deepa123@gmail.com', '$2y$10$NO6znZG/fn7j/yCO.DLkoeX/cEm3BEaFbHiL3Ay2Zm8TRr0KOprGK', '', 'booking');

-- --------------------------------------------------------

--
-- Table structure for table `orrs_passenger`
--

CREATE TABLE `orrs_passenger` (
  `pass_id` int(20) NOT NULL,
  `pass_fname` varchar(200) NOT NULL,
  `pass_lname` varchar(200) NOT NULL,
  `pass_phone` varchar(200) NOT NULL,
  `pass_addr` varchar(200) NOT NULL,
  `pass_email` varchar(200) NOT NULL,
  `pass_pwd` varchar(200) NOT NULL,
  `pass_dpic` varchar(200) NOT NULL,
  `pass_uname` varchar(200) NOT NULL,
  `pass_bday` varchar(200) NOT NULL,
  `pass_bio` longtext NOT NULL,
  `pass_train_number` varchar(200) NOT NULL,
  `pass_train_name` varchar(200) NOT NULL,
  `pass_dep_station` varchar(200) NOT NULL,
  `pass_dep_time` varchar(200) NOT NULL,
  `pass_arr_station` varchar(200) NOT NULL,
  `pass_train_fare` varchar(200) NOT NULL,
  `pass_fare_payment_code` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orrs_passenger`
--

INSERT INTO `orrs_passenger` (`pass_id`, `pass_fname`, `pass_lname`, `pass_phone`, `pass_addr`, `pass_email`, `pass_pwd`, `pass_dpic`, `pass_uname`, `pass_bday`, `pass_bio`, `pass_train_number`, `pass_train_name`, `pass_dep_station`, `pass_dep_time`, `pass_arr_station`, `pass_train_fare`, `pass_fare_payment_code`) VALUES
(33, 'sam', 'prajapati', '0147852369', 'diva', 'sam123@gmail.com', '$2y$10$JQLUzEZ9C20qVdLfxcwWPuCOWkIkBBMfkJlWvi2pymCmXikf7PIJm', '', 'sam_p', '', '', '12101', 'Jnaneshwari Express', 'Mumbai LTT', '08:30 AM', 'Howrah', '1950', '1234687'),
(34, 'kajal', 'gupta', '7991873441', 'kanjur', 'kajal123@gmail.com', '24e7b7d37fb084a8079033d6528894cdd06b63a2', '', 'kajal_g', '', '', '', '', '', '', '', '', ''),
(35, 'rahul', 'gupta', '0123654789', 'kanjur', 'rahul123@gmail.com', '$2y$10$tul/kL05t44hPawWJjVoguS1Km5OW4hItjcc8gUR7qgYviRGpMDxK', '', 'rahul_g', '', '', '', '', '', '', '', '', ''),
(36, 'raju', 'gupta', '9874563210', 'diva', 'raju123@gmail.com', '$2y$10$ud/gMIo5KUdCa8lnEJ.y3e/NAdjm9Sxh88l2ZyGBNxCqvDKgX/QZi', '', 'raju', '', '', '', '', '', '', '', '', ''),
(37, 'chiku', 'pal', '1231231230', 'bhandup', 'chiku123@gmail.com', '$2y$10$.NSUrYREC7UwYlag8aExCeq9NCEiE7.mrmtDvKPB0HEDL/xGYLXPW', '', 'chiku_p', '', '', '12137', 'Punjab Mail', 'Mumbai CST', '07:30 PM', 'Firozpur', '1600', '5652654'),
(38, 'rohan', 'gupta', '4564564560', 'bhandup', 'rohan123@gmail.com', '24e7b7d37fb084a8079033d6528894cdd06b63a2', '', 'rohan_g', '', '', '', '', '', '', '', '', ''),
(39, 'sandeep', 'prajapati', '7897897890', 'diva', 'sandeep123@gmail.com', '$2y$10$z1XzuYLg3HU5RTujWgo7oONVS7m62QXnA7C0481y9ZYSLfNbxA3L.', '', 'sandeep_p', '', '', '', '', '', '', '', '', ''),
(41, 'riya', 'gupta', '3213213210', 'thane', 'riya123@gmail.com', '$2y$10$wSAhE2x4nC2aHmR.ogHhiODEMbLOzMcdNrzjveHZbREhm1trQjJ/e', 'Screenshot (3).png', 'riya', '01/01/2005', 'hiii', '', '', '', '', '', '', '12345679'),
(42, 'Deepa', 'Gupta', '7989909402', 'Surya Nagar', 'deepa123@gmail.com', '$2y$10$LztN8CeAnkh.QdnHNt8v5uBb6LBEDhzfUE9zQ0T19GjtSWIZ9K2TG', 'fast-food.png', 'deepa', '01/01/2005', 'hello, I am deepa', '12249', 'Yuva Express', 'Kolkata', '01:30 PM', 'New Delhi', '1800', '100010021212'),
(43, 'kirtana', 'gupta', '3456789210', 'kanjur', 'kirtana123@gmail.com', '$2y$10$fBuckuT1OpLQUJqlg.i81eI9zPgboq0C6DKrzWkfrYFpGw/8VSHva', '', 'kirtana', '', '', '', '', '', '', '', '', '100010021212'),
(44, 'kashish', 'gupta', '1212121212', 'thane', 'kashish123@gmail.com', '$2y$10$f9sbCXMHbkVfHoSr2RqeuOFgbgnpJCyhFAiV8dnDH1AkK5bfH5bDS', '', 'kashish', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `orrs_passwordresets`
--

CREATE TABLE `orrs_passwordresets` (
  `pwd_id` int(20) NOT NULL,
  `email` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orrs_train`
--

CREATE TABLE `orrs_train` (
  `id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `route` varchar(200) NOT NULL,
  `current` varchar(200) NOT NULL,
  `destination` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL,
  `passengers` varchar(200) NOT NULL,
  `number` varchar(200) NOT NULL,
  `fare` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orrs_train`
--

INSERT INTO `orrs_train` (`id`, `name`, `route`, `current`, `destination`, `time`, `passengers`, `number`, `fare`) VALUES
(20, 'New Delhi Bhopal Shatabdi', 'New Delhi - Bhopal', 'New Delhi', 'Bhopal', '06:00 AM', '450', '12002', '1500'),
(21, 'Mumbai Rajdhani', 'Mumbai - Delhi', 'Mumbai Central', 'New Delhi', '04:00 PM', '500', '12951', '2100'),
(22, 'Lucknow Mail', 'Lucknow - New Delhi', 'Lucknow', 'New Delhi', '10:30 PM', '600', '12230', '750'),
(23, 'Tamil Nadu Express', 'New Delhi - Chennai', 'New Delhi', 'Chennai', '10:00 PM', '550', '12622', '1950'),
(24, 'Kolkata Mail', 'Mumbai - Kolkata', 'Mumbai CST', 'Howrah', '08:30 PM', '700', '12322', '1800'),
(25, 'Karnataka Express', 'Bangalore - New Delhi', 'Bangalore', 'New Delhi', '07:30 PM', '550', '12627', '2000'),
(26, 'Ajmer Shatabdi', 'New Delhi - Ajmer', 'New Delhi', 'Ajmer', '06:00 AM', '400', '12015', '1200'),
(27, 'Grand Trunk Express', 'Chennai - New Delhi', 'Chennai', 'New Delhi', '06:00 PM', '500', '12616', '1900'),
(28, 'Gitanjali Express', 'Mumbai - Howrah', 'Mumbai CST', 'Howrah', '06:00 AM', '750', '12860', '1700'),
(29, 'Kerala Express', 'New Delhi - Trivandrum', 'New Delhi', 'Trivandrum', '11:00 AM', '600', '12626', '2100'),
(30, 'August Kranti Rajdhani', 'Mumbai - Delhi', 'Mumbai Central', 'New Delhi', '05:40 PM', '480', '12953', '2200'),
(31, 'Purushottam Express', 'New Delhi - Puri', 'New Delhi', 'Puri', '10:30 PM', '650', '12802', '1600'),
(32, 'Rajdhani Express', 'Dibrugarh - New Delhi', 'Dibrugarh', 'New Delhi', '09:30 AM', '500', '12423', '2500'),
(33, 'Samta Express', 'Visakhapatnam - Delhi', 'Visakhapatnam', 'Hazrat Nizamuddin', '06:30 AM', '700', '12801', '1900'),
(34, 'Punjab Mail', 'Mumbai - Firozpur', 'Mumbai CST', 'Firozpur', '07:30 PM', '600', '12137', '1600'),
(35, 'Mangala Lakshadweep Express', 'Ernakulam - Delhi', 'Ernakulam', 'Hazrat Nizamuddin', '01:30 PM', '650', '12617', '2000'),
(36, 'Telangana Express', 'New Delhi - Hyderabad', 'New Delhi', 'Hyderabad', '06:25 PM', '550', '12724', '1900'),
(37, 'Bangalore Rajdhani', 'Bangalore - Delhi', 'Bangalore', 'New Delhi', '08:00 PM', '500', '22692', '2200'),
(38, 'Mangala Express', 'Delhi - Ernakulam', 'Hazrat Nizamuddin', 'Ernakulam', '09:15 AM', '600', '12618', '2100'),
(39, 'Magadh Express', 'New Delhi - Islampur', 'New Delhi', 'Islampur', '07:20 PM', '700', '12402', '1750'),
(41, 'Rajdhani Express', 'Howrah - New Delhi', 'Howrah', 'New Delhi', '04:55 PM', '500', '12301', '2200'),
(42, 'Jammu Rajdhani', 'Jammu - New Delhi', 'Jammu Tawi', 'New Delhi', '08:10 PM', '480', '12426', '2250'),
(43, 'Bihar Sampark Kranti', 'Darbhanga - New Delhi', 'Darbhanga', 'New Delhi', '08:30 AM', '650', '12565', '1800'),
(44, 'Navjeevan Express', 'Ahmedabad - Chennai', 'Ahmedabad', 'Chennai', '06:45 PM', '550', '12655', '1950'),
(45, 'K.K. Express', 'Bangalore - Guwahati', 'Bangalore', 'Guwahati', '08:15 AM', '600', '12650', '2500'),
(46, 'Dehradun Express', 'Dehradun - Chennai', 'Dehradun', 'Chennai', '10:25 PM', '580', '12688', '2100'),
(47, 'North East Express', 'Guwahati - Anand Vihar', 'Guwahati', 'Anand Vihar', '07:45 PM', '700', '12506', '1900'),
(48, 'Seemanchal Express', 'Jogbani - Anand Vihar', 'Jogbani', 'Anand Vihar', '08:30 PM', '600', '12487', '1700'),
(49, 'Vaishali Express', 'Saharsa - New Delhi', 'Saharsa', 'New Delhi', '06:30 AM', '650', '12553', '1750'),
(50, 'Rajdhani Express', 'New Jalpaiguri - New Delhi', 'NJP', 'New Delhi', '05:00 PM', '500', '12523', '2300'),
(51, 'Mahabodhi Express', 'Gaya - New Delhi', 'Gaya', 'New Delhi', '02:30 PM', '550', '12397', '1900'),
(52, 'Jnaneshwari Express', 'Mumbai - Howrah', 'Mumbai LTT', 'Howrah', '08:30 AM', '750', '12101', '1950'),
(53, 'Dakshin Express', 'Hyderabad - Hazrat Nizamuddin', 'Hyderabad', 'Hazrat Nizamuddin', '08:10 AM', '600', '12721', '1850'),
(54, 'Darjeeling Mail', 'Sealdah - New Jalpaiguri', 'Sealdah', 'NJP', '07:35 PM', '550', '12343', '1600'),
(55, 'Bhubaneswar Rajdhani', 'Bhubaneswar - New Delhi', 'Bhubaneswar', 'New Delhi', '09:30 AM', '500', '22823', '2300'),
(57, 'Howrah Express', 'Ahmedabad - Howrah', 'Ahmedabad', 'Howrah', '06:15 AM', '580', '12833', '1950'),
(58, 'Sanghamitra Express', 'Bangalore - Patna', 'Bangalore', 'Patna', '09:30 AM', '700', '12695', '2100'),
(59, 'Coromandel Express', 'Howrah - Chennai', 'Howrah', 'Chennai', '02:50 PM', '550', '12841', '1900'),
(60, 'Himsagar Express', 'Kanyakumari - Jammu', 'Kanyakumari', 'Jammu Tawi', '03:15 PM', '620', '16317', '2400'),
(61, 'Sampoorna Kranti Express', 'Patna - New Delhi', 'Patna', 'New Delhi', '05:15 AM', '600', '12393', '2000'),
(62, 'Garib Rath Express', 'Ranchi - Delhi', 'Ranchi', 'New Delhi', '07:20 AM', '500', '12878', '1600'),
(63, 'Shiv Ganga Express', 'Varanasi - New Delhi', 'Varanasi', 'New Delhi', '10:00 PM', '550', '12559', '1700'),
(64, 'Janshatabdi Express', 'Bhubaneswar - Howrah', 'Bhubaneswar', 'Howrah', '06:10 AM', '450', '12073', '1000'),
(65, 'Yuva Express', 'Kolkata - New Delhi', 'Kolkata', 'New Delhi', '01:30 PM', '700', '12249', '1800');

-- --------------------------------------------------------

--
-- Table structure for table `orrs_train_tickets`
--

CREATE TABLE `orrs_train_tickets` (
  `ticket_id` int(20) NOT NULL,
  `pass_name` varchar(200) NOT NULL,
  `pass_email` varchar(200) NOT NULL,
  `pass_addr` varchar(200) NOT NULL,
  `train_name` varchar(200) NOT NULL,
  `train_no` varchar(200) NOT NULL,
  `train_dep_stat` varchar(200) NOT NULL,
  `train_arr_stat` varchar(200) NOT NULL,
  `train_fare` varchar(200) NOT NULL,
  `fare_payment_code` varchar(200) NOT NULL,
  `confirmation` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orrs_train_tickets`
--

INSERT INTO `orrs_train_tickets` (`ticket_id`, `pass_name`, `pass_email`, `pass_addr`, `train_name`, `train_no`, `train_dep_stat`, `train_arr_stat`, `train_fare`, `fare_payment_code`, `confirmation`) VALUES
(26, 'vashu gupta', 'vashu123@gmail.com', 'suryanagar', 'Jnaneshwari Express', '12101', 'Mumbai LTT', 'Howrah', '1950', '112233445566778', 'Approved'),
(31, 'sam prajapati', 'sam123@gmail.com', 'diva', 'Jnaneshwari Express', '12101', 'Mumbai LTT', 'Howrah', '1950', '1234687', 'Approved'),
(33, 'chiku pal', 'chiku123@gmail.com', 'bhandup', 'Ajmer Shatabdi', '12015', 'New Delhi', 'Ajmer', '1200', '5652654', 'Approved'),
(34, 'chiku pal', 'chiku123@gmail.com', 'bhandup', 'Ajmer Shatabdi', '12015', 'New Delhi', 'Ajmer', '1200', '5652654', 'Approved'),
(36, 'riya gupta', 'riya123@gmail.com', 'thane', 'Janshatabdi Express', '12073', 'Bhubaneswar', 'Howrah', '1000', '12345679', 'Approved'),
(37, 'riya gupta', 'riya123@gmail.com', 'thane', 'Janshatabdi Express', '12073', 'Bhubaneswar', 'Howrah', '1000', '12345679', 'Approved'),
(41, 'Deepa Gupta', 'deepa123@gmail.com', 'Surya Nagar', 'Ajmer Shatabdi', '12015', 'New Delhi', 'Ajmer', '1200', '100010021212', 'Approved'),
(42, 'Deepa Gupta', 'deepa123@gmail.com', 'Surya Nagar', 'Ajmer Shatabdi', '12015', 'New Delhi', 'Ajmer', '1200', '100010021212', 'Approved'),
(43, 'Deepa Gupta', 'deepa123@gmail.com', 'Surya Nagar', 'Ajmer Shatabdi', '12015', 'New Delhi', 'Ajmer', '1200', '100010021212', 'Approved'),
(44, 'Deepa Gupta', 'deepa123@gmail.com', 'Surya Nagar', 'Ajmer Shatabdi', '12015', 'New Delhi', 'Ajmer', '1200', '100010021212', 'Approved'),
(45, 'Deepa Gupta', 'deepa123@gmail.com', 'Surya Nagar', 'Ajmer Shatabdi', '12015', 'New Delhi', 'Ajmer', '1200', '100010021212', 'Approved'),
(46, 'Deepa Gupta', 'deepa123@gmail.com', 'Surya Nagar', 'Yuva Express', '12249', 'Kolkata', 'New Delhi', '1800', '100010021212', 'Approved'),
(47, 'Deepa Gupta', 'deepa123@gmail.com', 'Surya Nagar', 'Yuva Express', '12249', 'Kolkata', 'New Delhi', '1800', '100010021212', 'Approved'),
(48, 'kirtana gupta', 'kirtana123@gmail.com', 'kanjur', 'Ajmer Shatabdi', '12015', 'New Delhi', 'Ajmer', '1200', '100010021212', 'Approved'),
(49, 'kirtana gupta', 'kirtana123@gmail.com', 'kanjur', 'New Delhi Bhopal Shatabdi', '12002', 'New Delhi', 'Bhopal', '1500', '100010021212', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orrs_admin`
--
ALTER TABLE `orrs_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `orrs_employee`
--
ALTER TABLE `orrs_employee`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `orrs_passenger`
--
ALTER TABLE `orrs_passenger`
  ADD PRIMARY KEY (`pass_id`);

--
-- Indexes for table `orrs_passwordresets`
--
ALTER TABLE `orrs_passwordresets`
  ADD PRIMARY KEY (`pwd_id`);

--
-- Indexes for table `orrs_train`
--
ALTER TABLE `orrs_train`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orrs_train_tickets`
--
ALTER TABLE `orrs_train_tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orrs_admin`
--
ALTER TABLE `orrs_admin`
  MODIFY `admin_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orrs_employee`
--
ALTER TABLE `orrs_employee`
  MODIFY `emp_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1021;

--
-- AUTO_INCREMENT for table `orrs_passenger`
--
ALTER TABLE `orrs_passenger`
  MODIFY `pass_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `orrs_passwordresets`
--
ALTER TABLE `orrs_passwordresets`
  MODIFY `pwd_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `orrs_train`
--
ALTER TABLE `orrs_train`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `orrs_train_tickets`
--
ALTER TABLE `orrs_train_tickets`
  MODIFY `ticket_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
