<?php
session_start();
include('assets/inc/config.php');

if (isset($_POST['Create_Profile'])) {
    $emp_fname = trim($_POST['emp_fname']);
    $emp_lname = trim($_POST['emp_lname']);
    $emp_nat_idno = trim($_POST['emp_nat_idno']);
    $emp_phone = trim($_POST['emp_phone']);
    $emp_addr = trim($_POST['emp_addr']);
    $emp_uname = trim($_POST['emp_uname']);
    $emp_email = trim($_POST['emp_email']);
    $emp_dept = trim($_POST['emp_dept']);
    $emp_pwd = password_hash($_POST['emp_pwd'], PASSWORD_BCRYPT);

    // Check if employee already exists (by phone, email, or national ID)
    $check_query = "SELECT emp_id FROM orrs_employee WHERE emp_phone = ? OR emp_email = ? OR emp_nat_idno = ?";
    $check_stmt = $mysqli->prepare($check_query);
    $check_stmt->bind_param('sss', $emp_phone, $emp_email, $emp_nat_idno);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        $err = "Employee already registered with this Phone, Email, or National ID!";
    } else {
        $query = "INSERT INTO orrs_employee (emp_fname, emp_lname, emp_nat_idno, emp_phone, emp_addr, emp_uname, emp_email, emp_dept, emp_pwd) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('sssssssss', $emp_fname, $emp_lname, $emp_nat_idno, $emp_phone, $emp_addr, $emp_uname, $emp_email, $emp_dept, $emp_pwd);

        if ($stmt->execute()) {
            $success = "Employee's Account Has Been Created";
        } else {
            $err = "Error! Please try again later.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php'); ?>
<body>
<div class="be-wrapper be-fixed-sidebar">
    <?php include('assets/inc/navbar.php'); ?>
    <?php include('assets/inc/sidebar.php'); ?>
    <div class="be-content">
        <div class="page-head">
            <h2 class="page-head-title">Add Employee</h2>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb page-head-nav">
                    <li class="breadcrumb-item"><a href="emp-dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="admin-manage-employee.php">Employee</a></li>
                    <li class="breadcrumb-item active">Add</li>
                </ol>
            </nav>
        </div>

        <?php if (isset($success)) { ?>
            <script>setTimeout(() => { swal("Success!", "<?php echo $success; ?>", "success"); }, 100);</script>
        <?php } ?>
        <?php if (isset($err)) { ?>
            <script>setTimeout(() => { swal("Failed!", "<?php echo $err; ?>", "error"); }, 100);</script>
        <?php } ?>

        <div class="main-content container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-border-color card-border-color-success">
                        <div class="card-header">Create Employee Profile <span class="card-subtitle">Fill All Details</span></div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">First Name</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="emp_fname" required type="text">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Last Name</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="emp_lname" required type="text">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">National ID</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="emp_nat_idno" required type="text">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Phone Number</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="emp_phone" required type="tel" pattern="[0-9]{10}">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Address</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="emp_addr" required type="text">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Email</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="emp_email" required type="email">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Department</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="emp_dept" required type="text">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Username</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="emp_uname" required type="text">
                                    </div>
                                </div>
                                <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Password</label>
                                    <div class="col-12 col-sm-8 col-lg-6" style="position: relative;">
                                       <input class="form-control" id="emp_pwd" name="emp_pwd" required type="password" minlength="6">
                                       <span class="toggle-password" onclick="togglePassword('emp_pwd')" 
                                        style="position: absolute; right: 30px; top: 50%; transform: translateY(-50%); cursor: pointer;">
                                          👁️‍🗨️
                                     </span>
                                     </div>
                                </div>
                                <div class="col-sm-6">
                                    <p class="text-right">
                                        <input class="btn btn-space btn-success" value="Add Employee" name="Create_Profile" type="submit">
                                        <button class="btn btn-space btn-danger" type="reset">Cancel</button>
                                    </p>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('assets/inc/footer.php'); ?>
        </div>
    </div>
    <script src="assets/js/app.js"></script>
    <script>
    function togglePassword(id) {
        var input = document.getElementById(id);
        if (input) {
            input.type = (input.type === "password") ? "text" : "password";
        }
    }
    </script>
    
</body>
</html>
