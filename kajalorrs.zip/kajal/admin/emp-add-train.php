<?php
session_start();
include('assets/inc/config.php');
include('assets/inc/checklogin.php');
check_login();
$aid = $_SESSION['admin_id'];

if (isset($_POST['add_train'])) {
    $name = trim($_POST['name']);
    $route = trim($_POST['route']);
    $current = trim($_POST['current']);
    $destination = trim($_POST['destination']);
    $time = trim($_POST['time']);
    $number = trim($_POST['number']);
    $fare = trim($_POST['fare']);
    $passengers = trim($_POST['passengers']);

    // Check if train number already exists
    $check_query = "SELECT * FROM orrs_train WHERE number = ?";
    $stmt_check = $mysqli->prepare($check_query);
    $stmt_check->bind_param('s', $number);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        $err = "Train Number $number already exists!";
    } else {
        // Insert new train if train number does not exist
        $query = "INSERT INTO orrs_train (name, route, current, destination, time, number, fare, passengers) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('ssssssss', $name, $route, $current, $destination, $time, $number, $fare, $passengers);

        if ($stmt->execute()) {
            $succ = "Train Added Successfully!";
        } else {
            $err = "Error adding train. Please try again!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php'); ?>
<body>
    <div class="be-wrapper be-fixed-sidebar">
        <?php include('assets/inc/navbar.php'); ?>
        <?php include('assets/inc/sidebar.php'); ?>

        <div class="be-content">
            <div class="page-head">
                <h2 class="page-head-title">Add Train</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb page-head-nav">
                        <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="#">Trains</a></li>
                        <li class="breadcrumb-item active">Add Train</li>
                    </ol>
                </nav>
            </div>

            <!-- Success or Error Alerts -->
            <?php if (isset($succ)) { ?>
                <script>
                    setTimeout(function () { swal("Success!", "<?php echo $succ; ?>", "success"); }, 100);
                </script>
            <?php } ?>
            <?php if (isset($err)) { ?>
                <script>
                    setTimeout(function () { swal("Failed!", "<?php echo $err; ?>", "error"); }, 100);
                </script>
            <?php } ?>

            <div class="main-content container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card card-border-color card-border-color-success">
                            <div class="card-header card-header-divider">Add New Train <span class="card-subtitle"> Please Fill All Details</span></div>
                            <div class="card-body">
                                <form method="POST">
                                    <div class="form-group row">
                                        <label class="col-12 col-sm-3 col-form-label text-sm-right"> Train Name</label>
                                        <div class="col-12 col-sm-8 col-lg-6">
                                            <input class="form-control" name="name" type="text" required placeholder="Enter Train Name">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-12 col-sm-3 col-form-label text-sm-right"> Train Number</label>
                                        <div class="col-12 col-sm-8 col-lg-6">
                                            <input class="form-control" name="number" type="text" required placeholder="Enter Train Number">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-12 col-sm-3 col-form-label text-sm-right"> Train Route</label>
                                        <div class="col-12 col-sm-8 col-lg-6">
                                            <input class="form-control" name="route" type="text" required placeholder="Format: [Source] - [Destination]">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-12 col-sm-3 col-form-label text-sm-right"> Departure</label>
                                        <div class="col-12 col-sm-8 col-lg-6">
                                            <input class="form-control" name="current" type="text" required placeholder="Enter Source/Departure">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-12 col-sm-3 col-form-label text-sm-right"> Arrival</label>
                                        <div class="col-12 col-sm-8 col-lg-6">
                                            <input class="form-control" name="destination" type="text" required placeholder="Enter Destination/Arrival">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-12 col-sm-3 col-form-label text-sm-right"> Departure Time</label>
                                        <div class="col-12 col-sm-8 col-lg-6">
                                            <input class="form-control" name="time" type="text" required placeholder="Enter Train's Departure Time">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-12 col-sm-3 col-form-label text-sm-right"> Number of passengers</label>
                                        <div class="col-12 col-sm-8 col-lg-6">
                                            <input class="form-control" name="passengers" type="text" required placeholder="Enter Total Number of Passengers">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-12 col-sm-3 col-form-label text-sm-right"> Train Fare</label>
                                        <div class="col-12 col-sm-8 col-lg-6">
                                            <input class="form-control" name="fare" type="text" required placeholder="₹">
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-6">
                                        <p class="text-right">
                                            <input class="btn btn-space btn-success" value="Add Train" name="add_train" type="submit">
                                            <button class="btn btn-space btn-danger" type="reset">Cancel</button>
                                        </p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include('assets/inc/footer.php'); ?>
        </div>
    </div>
    
    <script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
    <script src="assets/lib/perfect-scrollbar/js/perfect-scrollbar.min.js" type="text/javascript"></script>
    <script src="assets/lib/bootstrap/dist/js/bootstrap.bundle.min.js" type="text/javascript"></script>
    <script src="assets/js/app.js" type="text/javascript"></script>
    <script src="assets/lib/jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
    <script src="assets/lib/jquery.nestable/jquery.nestable.js" type="text/javascript"></script>
    <script src="assets/lib/moment.js/min/moment.min.js" type="text/javascript"></script>
    <script src="assets/lib/datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
    <script src="assets/lib/select2/js/select2.min.js" type="text/javascript"></script>
    <script src="assets/lib/select2/js/select2.full.min.js" type="text/javascript"></script>
    <script src="assets/lib/bootstrap-slider/bootstrap-slider.min.js" type="text/javascript"></script>
    <script src="assets/lib/bs-custom-file-input/bs-custom-file-input.js" type="text/javascript"></script>
    <script type="text/javascript">
      $(document).ready(function(){
      	//-initialize the javascript
      	App.init();
      	App.formElements();
      });
    </script>
</body>
</html>
