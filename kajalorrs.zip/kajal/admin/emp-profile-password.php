<?php
session_start();
include('assets/inc/config.php');
include('assets/inc/checklogin.php');
check_login();
$aid = $_SESSION['admin_id'];

if (isset($_POST['Update_Password'])) {
    $old_password = $_POST['old_pwd'];
    $new_password = $_POST['admin_pwd'];
    $confirm_password = $_POST['confirm_admin_pwd'];

    // Fetch stored password from the database
    $ret = "SELECT admin_pwd FROM orrs_admin WHERE admin_id=?";
    $stmt = $mysqli->prepare($ret);
    $stmt->bind_param('i', $aid);
    $stmt->execute();
    $stmt->bind_result($db_password);
    $stmt->fetch();
    $stmt->close();

    // Hash the entered old password for verification
    $hashed_old_pwd = sha1(md5($old_password));

    if ($hashed_old_pwd !== $db_password) {
        $err = "Old Password is Wrong!";
    } elseif ($new_password !== $confirm_password) {
        $err = "New Password and Confirm Password do not match!";
    } else {
        // Hash new password
        $hashed_new_pwd = sha1(md5($new_password));

        // Update password in database
        $query = "UPDATE orrs_admin SET admin_pwd = ? WHERE admin_id=?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('si', $hashed_new_pwd, $aid);
        $stmt->execute();

        if ($stmt) {
            $succ1 = "Password Updated Successfully";
        } else {
            $err = "Please Try Again Later";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Head -->
<?php include('assets/inc/head.php'); ?>
<!-- End Head -->

<body>
    <div class="be-wrapper be-fixed-sidebar">
        <!-- Navigation Bar -->
        <?php include('assets/inc/navbar.php'); ?>
        <!-- End Navigation Bar -->

        <!-- Sidebar -->
        <?php include('assets/inc/sidebar.php'); ?>
        <!-- End Sidebar -->

        <div class="be-content">
            <div class="page-head">
                <h2 class="page-head-title">Change Password</h2>
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb page-head-nav">
                        <li class="breadcrumb-item"><a href="emp-dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="#">Profile</a></li>
                        <li class="breadcrumb-item active">Change Password</li>
                    </ol>
                </nav>
            </div>

            <?php if (isset($succ1)) { ?>
                <script>
                    setTimeout(function() {
                        swal("Success!", "<?php echo $succ1; ?>", "success");
                    }, 100);
                </script>
            <?php } ?>

            <?php if (isset($err)) { ?>
                <script>
                    setTimeout(function() {
                        swal("Failed!", "<?php echo $err; ?>", "error");
                    }, 100);
                </script>
            <?php } ?>

            <div class="main-content container-fluid">
                <?php
                $ret = "SELECT * FROM orrs_admin WHERE admin_id=?";
                $stmt = $mysqli->prepare($ret);
                $stmt->bind_param('i', $aid);
                $stmt->execute();
                $res = $stmt->get_result();
                while ($row = $res->fetch_object()) {
                ?>
                    <div class="col-md-12">
                        <div class="card card-border-color card-border-color-success">
                            <div class="card-header card-header-divider">Change Password<span class="card-subtitle">Fill All Details</span></div>
                            <div class="card-body">
                                <form method="POST">
                                    <div class="form-group row">
                                        <label class="col-12 col-sm-3 col-form-label text-sm-right" for="oldPassword">Old Password</label>
                                        <div class="col-12 col-sm-8 col-lg-6 position-relative">
                                            <input class="form-control" name="old_pwd" id="oldPassword" type="password" required>
                                            <span class="toggle-password" onclick="togglePassword('oldPassword')" style="position: absolute; right: 30px; top: 50%; transform: translateY(-50%); cursor: pointer;">👁️‍🗨️</span>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-12 col-sm-3 col-form-label text-sm-right" for="newPassword">New Password</label>
                                        <div class="col-12 col-sm-8 col-lg-6 position-relative">
                                            <input class="form-control" name="admin_pwd" id="newPassword" type="password" required>
                                            <span class="toggle-password" onclick="togglePassword('newPassword')" style="position: absolute; right: 30px; top: 50%; transform: translateY(-50%); cursor: pointer;">👁️‍🗨️</span>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-12 col-sm-3 col-form-label text-sm-right" for="confirmPassword">Confirm New Password</label>
                                        <div class="col-12 col-sm-8 col-lg-6 position-relative">
                                            <input class="form-control" name="confirm_admin_pwd" id="confirmPassword" type="password" required>
                                            <span class="toggle-password" onclick="togglePassword('confirmPassword')" style="position: absolute; right: 30px; top: 50%; transform: translateY(-50%); cursor: pointer;">👁️‍🗨️</span>
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <p class="text-right">
                                            <input class="btn btn-space btn-success" value="Change Password" name="Update_Password" type="submit">
                                            <button class="btn btn-space btn-danger" type="reset">Cancel</button>
                                        </p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>

        <!-- Footer -->
        <?php include('assets/inc/footer.php'); ?>
        <!-- End Footer -->
    </div>

    <script src="assets/lib/jquery/jquery.min.js"></script>
    <script src="assets/lib/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/app.js"></script>

    <script>
        function togglePassword(id) {
            var input = document.getElementById(id);
            input.type = (input.type === "password") ? "text" : "password";
        }
    </script>

</body>
</html>
