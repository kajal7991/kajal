<!-- Server-side code to handle passenger sign-up -->
<?php
session_start();
include('assets/inc/config.php');

if (isset($_POST['Create_Profile'])) {
    $pass_fname = trim($_POST['pass_fname']);
    $pass_lname = trim($_POST['pass_lname']);
    $pass_phone = trim($_POST['pass_phone']);
    $pass_addr = trim($_POST['pass_addr']);
    $pass_uname = trim($_POST['pass_uname']);
    $pass_email = trim($_POST['pass_email']);
    $pass_pwd = password_hash($_POST['pass_pwd'], PASSWORD_BCRYPT); // Secure password hashing

    // Check if phone number already exists
    $check_query = "SELECT pass_id FROM orrs_passenger WHERE pass_phone = ?";
    $check_stmt = $mysqli->prepare($check_query);
    $check_stmt->bind_param('s', $pass_phone);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        $err = "Passenger already registered with this phone number!";
    } else {
        // Insert new passenger
        $query = "INSERT INTO orrs_passenger (pass_fname, pass_lname, pass_phone, pass_addr, pass_uname, pass_email, pass_pwd) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('sssssss', $pass_fname, $pass_lname, $pass_phone, $pass_addr, $pass_uname, $pass_email, $pass_pwd);

        if ($stmt->execute()) {
            $success = "Passenger's Account Has Been Created";
        } else {
            $err = "Error! Please try again later.";
        }
    }
}
?>
<!-- End Server-Side -->

<!DOCTYPE html>
<html lang="en">
<!--Head-->
<?php include('assets/inc/head.php'); ?>
<!--End Head-->
<body>
<div class="be-wrapper be-fixed-sidebar">
    <!-- Navigation Bar -->
    <?php include('assets/inc/navbar.php'); ?>
    <!-- End Navigation Bar -->

    <!-- Sidebar -->
    <?php include('assets/inc/sidebar.php'); ?>
    <!-- End Sidebar -->

    <div class="be-content">
        <div class="page-head">
            <h2 class="page-head-title">Create Passenger</h2>
            <nav aria-label="breadcrumb" role="navigation">
                <ol class="breadcrumb page-head-nav">
                    <li class="breadcrumb-item"><a href="emp-dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="#">Passenger</a></li>
                    <li class="breadcrumb-item active">Add</li>
                </ol>
            </nav>
        </div>

        <!-- Success and Error Alerts -->
        <?php if (isset($success)) { ?>
            <script>
                setTimeout(function () {
                    swal("Success!", "<?php echo $success; ?>", "success");
                }, 100);
            </script>
        <?php } ?>
        <?php if (isset($err)) { ?>
            <script>
                setTimeout(function () {
                    swal("Failed!", "<?php echo $err; ?>", "error");
                }, 100);
            </script>
        <?php } ?>

        <div class="main-content container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-border-color card-border-color-success">
                        <div class="card-header card-header-divider">
                            Create Passenger Profile <span class="card-subtitle">Fill All Details</span>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">First Name</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="pass_fname" required type="text">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Last Name</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="pass_lname" required type="text">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Contact Number</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="pass_phone" required type="tel" pattern="[0-9]{10}">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Address</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="pass_addr" required type="text">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Email</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="pass_email" required type="email">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Username</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <input class="form-control" name="pass_uname" required type="text">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Password</label>
                                    <div class="col-12 col-sm-8 col-lg-6" style="position: relative;">
                                        <input class="form-control" id="pass_pwd" name="pass_pwd" required type="password" minlength="6">
                                        <span class="toggle-password" onclick="togglePassword('pass_pwd')" 
                                              style="position: absolute; right: 30px; top: 50%; transform: translateY(-50%); cursor: pointer;">
                                            👁️‍🗨️
                                        </span>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <p class="text-right">
                                        <input class="btn btn-space btn-success" value="Create Passenger" name="Create_Profile" type="submit">
                                        <button class="btn btn-space btn-danger" type="reset">Cancel</button>
                                    </p>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <?php include('assets/inc/footer.php'); ?>
            <!-- End Footer -->
        </div>
    </div>

    <script src="assets/lib/jquery/jquery.min.js"></script>
    <script src="assets/lib/perfect-scrollbar/js/perfect-scrollbar.min.js"></script>
    <script src="assets/lib/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/app.js"></script>
    <script src="assets/lib/jquery-ui/jquery-ui.min.js"></script>
    <script src="assets/lib/jquery.nestable/jquery.nestable.js"></script>
    <script src="assets/lib/moment.js/min/moment.min.js"></script>
    <script src="assets/lib/datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
    <script src="assets/lib/select2/js/select2.min.js"></script>
    <script src="assets/lib/bootstrap-slider/bootstrap-slider.min.js"></script>
    <script src="assets/lib/bs-custom-file-input/bs-custom-file-input.js"></script>

    <script>
    function togglePassword(id) {
        var input = document.getElementById(id);
        if (input) {
            input.type = (input.type === "password") ? "text" : "password";
        }
    }
    </script>

    <script>
        $(document).ready(function () {
            App.init();
            App.formElements();
        });
    </script>
</body>
</html>
