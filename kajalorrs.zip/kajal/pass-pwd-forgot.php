<?php
session_start();
include('assets/inc/config.php');

$email_verified = false;
$err = "";

// Step 1: Verify Email and Phone
if (isset($_POST['verify_user'])) {
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);

    // Check if email and phone exist in the database
    $query = "SELECT pass_id FROM orrs_passenger WHERE LOWER(pass_email) = LOWER(?) AND pass_phone = ?";
    $stmt = $mysqli->prepare($query);
    if ($stmt) {
        $stmt->bind_param('ss', $email, $phone);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($pass_id);
            $stmt->fetch();
            $_SESSION['pass_id'] = $pass_id;
            $_SESSION['email_verified'] = true;
            $email_verified = true;
        } else {
            $err = "Email or phone number is incorrect. Please try again.";
        }
        $stmt->close();
    } else {
        $err = "Database error. Please try again later.";
    }
}

// Step 2: Update Password
if (isset($_POST['update_pwd']) && isset($_SESSION['email_verified']) && $_SESSION['email_verified'] === true) {
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);
    $pass_id = $_SESSION['pass_id'];

    // Validate password
    if (!preg_match('/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $new_password)) {
        $err = "Password must be at least 8 characters long and include a letter, a number, and a special character.";
    } elseif ($new_password !== $confirm_password) {
        $err = "Passwords do not match.";
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $query = "UPDATE orrs_passenger SET pass_pwd = ? WHERE pass_id = ?";
        $stmt = $mysqli->prepare($query);
        if ($stmt) {
            $stmt->bind_param('si', $hashed_password, $pass_id);
            if ($stmt->execute()) {
                session_destroy(); // Clear session for security
                echo "<script src='assets/js/swal.js'></script>";
                echo "<script>
                    setTimeout(function () { 
                        swal({
                            title: 'Success!',
                            text: 'Password reset successfully! Redirecting to login...',
                            icon: 'success',
                            button: 'OK'
                        }).then(() => { 
                            window.location.href = 'pass-login.php'; 
                        });
                    }, 100);
                </script>";
                exit();
            } else {
                $err = "Error updating password. Please try again.";
            }
            $stmt->close();
        } else {
            $err = "Database error. Please try again later.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="assets/css/app.css"/>
    <script src="assets/js/swal.js"></script>
</head>
<body>
    <div class="be-wrapper be-login">
        <div class="be-content">
            <div class="splash-container forgot-password">
                <div class="card">
                    <div class="card-header">
                        <img class="logo-img" src="assets/img/logo-xx.png" alt="logo" width="102">
                        <span class="splash-description">Reset Your Password</span>
                    </div>
                    <div class="card-body">
                        <?php if(isset($err) && $err != "") { ?>
                        <script>
                            setTimeout(function () { 
                                swal("Failed!", "<?php echo $err; ?>", "error");
                            }, 100);
                        </script>
                        <?php } ?>

                        <!-- Step 1: Verify Email and Phone -->
                        <form method="POST" id="verifyForm" <?php echo $email_verified ? 'style="display: none;"' : ''; ?>>
                            <p>Enter your registered Email and Phone Number.</p>
                            <div class="form-group pt-4">
                                <input class="form-control" type="email" name="email" required placeholder="Your Email">
                            </div>
                            <div class="form-group pt-4">
                                <input class="form-control" type="text" name="phone" required placeholder="Your Phone Number">
                            </div>
                            <div class="form-group pt-1">
                                <input type="submit" name="verify_user" class="btn btn-primary btn-block" value="Verify">
                            </div>
                        </form>

                        <!-- Step 2: Reset Password (Only show after verification) -->
                        <?php if ($email_verified) { ?>
                        <form method="POST" id="resetForm">
                            <p>Enter your new password below.</p>
                            <div class="form-group pt-4">
                                <div style="position: relative;">
                                    <input class="form-control" type="password" name="new_password" id="new_password" required placeholder="New Password">
                                    <span class="toggle-password" onclick="togglePassword('new_password')" 
                                        style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer;">
                                        👁️‍🗨️
                                    </span>
                                </div>
                                <small>Password must be 8+ characters with at least one letter, one number, and one special character.</small>
                            </div>
                            <div class="form-group pt-4">
                                <div style="position: relative;">
                                    <input class="form-control" type="password" name="confirm_password" id="confirm_password" required placeholder="Confirm Password">
                                    <span class="toggle-password" onclick="togglePassword('confirm_password')" 
                                        style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer;">
                                        👁️‍🗨️
                                    </span>
                                </div>
                            </div>
                            <div class="form-group pt-1">
                                <input type="submit" name="update_pwd" class="btn btn-primary btn-block" value="Update Password">
                            </div>
                        </form>
                        <?php } ?>
                    </div>
                </div>
                <div class="splash-footer"><a href="pass-login.php">Home</a></div>
                <div class="splash-footer">&copy; 2024- <?php echo date ('Y');?> Online Railway Reservation System | Developed By Kajal Gupta</div>
            </div>
        </div>
    </div>

    <script src="assets/lib/jquery/jquery.min.js"></script>
    <script src="assets/lib/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function(){
            App.init();

            // Password validation
            $("#resetForm").on("submit", function(e) {
                let password = $("#new_password").val();
                let confirmPassword = $("#confirm_password").val();
                let regex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
                
                if (!regex.test(password)) {
                    swal("Error!", "Password must contain at least 8 characters, including a letter, a number, and a special character.", "error");
                    e.preventDefault();
                } else if (password !== confirmPassword) {
                    swal("Error!", "Passwords do not match.", "error");
                    e.preventDefault();
                }
            });
        });

        // JavaScript to toggle password visibility
        function togglePassword(id) {
            var input = document.getElementById(id);
            if (input.type === "password") {
                input.type = "text";
            } else {
                input.type = "password";
            }
        }
    </script>
</body>
</html>
