<?php
    session_start();
    include('assets/inc/config.php');
    include('assets/inc/checklogin.php');
    check_login();
    $aid=$_SESSION['pass_id'];
    
    if(isset($_POST['train_fare_confirm_checkout'])) {
        $pass_name = $_POST['pass_name'];
        $pass_addr = $_POST['pass_addr'];
        $pass_email = $_POST['pass_email'];        
        $train_name = $_POST['train_name'];
        $train_no = $_POST['train_no'];
        $train_dep_stat = $_POST['train_dep_stat'];
        $train_arr_stat = $_POST['train_arr_stat'];
        $train_fare = $_POST['train_fare'];
        $fare_payment_code = $_POST['fare_payment_code'];
        
        // SQL query to insert the ticket information
        $query = "INSERT INTO orrs_train_tickets (pass_name, pass_addr, pass_email, train_name, train_no, train_dep_stat, train_arr_stat, train_fare, fare_payment_code) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('sssssssss', $pass_name, $pass_addr, $pass_email, $train_name, $train_no, $train_dep_stat, $train_arr_stat, $train_fare, $fare_payment_code);
        $stmt->execute();
        
        if($stmt) {
            $succ = "Ticket Payment Confirmed";
        } else {
            $err = "Please Try Again Later";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php');?>
<body>
    <div class="be-wrapper be-fixed-sidebar">
        <?php include('assets/inc/navbar.php'); ?>
        <?php include('assets/inc/sidebar.php'); ?>
        <div class="be-content">
            <div class="page-head">
                <h2 class="page-head-title">Train Ticket Checkout</h2>
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb page-head-nav">
                        <li class="breadcrumb-item"><a href="pass-dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="#">Tickets</a></li>
                        <li class="breadcrumb-item"><a href="#">Checkout</a></li>
                    </ol>
                </nav>
            </div>
            
            <?php if(isset($succ)) { ?>
            <script>
                setTimeout(function () {
                    swal({
                        title: "Success!",
                        text: "<?php echo $succ; ?>!",
                        icon: "success"
                    }).then(() => {
                        window.location.href = "pass-print-ticket.php";
                    });
                }, 100);
            </script>
            <?php } ?>
            
            <?php if(isset($err)) { ?>
            <script>
                setTimeout(function () {
                    swal("Failed!", "<?php echo $err; ?>!", "error");
                }, 100);
            </script>
            <?php } ?>
            
            <div class="main-content container-fluid">
                <?php
                    $ret = "SELECT * FROM orrs_passenger WHERE pass_id = ?";
                    $stmt = $mysqli->prepare($ret);
                    $stmt->bind_param('i', $aid);
                    $stmt->execute();
                    $res = $stmt->get_result();
                    while($row = $res->fetch_object()) {
                ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card card-border-color card-border-color-success">
                            <div class="card-header card-header-divider"></div>
                            <div class="card-body">
                                <form method="POST">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Name</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" readonly name="pass_name" value="<?php echo $row->pass_fname . ' ' . $row->pass_lname; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Email</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" readonly name="pass_email" value="<?php echo $row->pass_email; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Address</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" readonly name="pass_addr" value="<?php echo $row->pass_addr; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Booked Train Number</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" readonly name="train_no" value="<?php echo $row->pass_train_number; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Booked Train Name</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" readonly name="train_name" value="<?php echo $row->pass_train_name; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Departure</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" readonly name="train_dep_stat" value="<?php echo $row->pass_dep_station; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Arrival</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" readonly name="train_arr_stat" value="<?php echo $row->pass_arr_station; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Train Fare</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" readonly name="train_fare" value="<?php echo $row->pass_train_fare; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Payment Code</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" readonly name="fare_payment_code" value="<?php echo $row->pass_fare_payment_code; ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="text-right">
                                            <input class="btn btn-success" value="Confirm Payment" name="train_fare_confirm_checkout" type="submit">
                                            <button class="btn btn-secondary">Cancel</button>
                                        </p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
            <?php include('assets/inc/footer.php'); ?>
        </div>
    </div>
</body>
</html>