<?php
session_start();
include('assets/inc/config.php'); // Get configuration file

if (isset($_POST['emp_login'])) {
    $emp_email = trim($_POST['emp_email']);
    $emp_pwd = trim($_POST['emp_pwd']);

    // Prepare statement to fetch user details
    $stmt = $mysqli->prepare("SELECT emp_id, emp_pwd FROM orrs_employee WHERE emp_email=?");
    if ($stmt) {
        $stmt->bind_param('s', $emp_email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($emp_id, $hashed_pwd);
            $stmt->fetch();

            // Verify password using password_verify()
            if (password_verify($emp_pwd, $hashed_pwd)) {
                session_regenerate_id(true); // Prevent session fixation
                $_SESSION['emp_id'] = $emp_id; // Assign session variable

                header("location:emp-dashboard.php");
                exit();
            } else {
                $error = "Invalid password. Please try again.";
            }
        } else {
            $error = "No account found with this email.";
        }
        $stmt->close();
    } else {
        $error = "Database error. Please try again later.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Employee Login | Online Railway Reservation System</title>
    <link rel="stylesheet" type="text/css" href="assets/lib/perfect-scrollbar/css/perfect-scrollbar.css"/>
    <link rel="stylesheet" type="text/css" href="assets/lib/material-design-icons/css/material-design-iconic-font.min.css"/>
    <link rel="stylesheet" href="assets/css/app.css" type="text/css"/>
    <script src="assets/js/swal.js"></script>

    <?php if (isset($error)) { ?>
    <script>
        setTimeout(function () { 
            swal("Failed!", "<?php echo $error; ?>", "error");
        }, 100);
    </script>
    <?php } ?>
</head>
<body class="be-splash-screen">
    <div class="be-wrapper be-login">
        <div class="be-content">
            <div class="main-content container-fluid">
                <div class="splash-container">
                    <div class="card card-border-color card-border-color-success">
                        <div class="card-header">
                            <img class="logo-img" src="assets/img/logo-xx.png" alt="logo" width="102">
                            <span class="splash-description">Please enter your login details.</span>
                        </div>
                        <div class="card-body">
                            <!-- Login Form -->
                            <form method="POST" id="loginForm">
                                <div class="login-form">
                                    <div class="form-group">
                                        <input class="form-control" name="emp_email" type="email" required placeholder="Email">
                                    </div>

                                    <div class="form-group">
                                        <div style="position: relative;">
                                            <input class="form-control" name="emp_pwd" id="emp_pwd" type="password" required placeholder="Password">
                                            <span class="toggle-password" onclick="togglePassword('emp_pwd')" 
                                                style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer;">
                                                👁️‍🗨️
                                            </span>
                                        </div>
                                    </div>

                                    <div class="form-group row login-tools">
                                        <div class="col-6 login-remember">
                                            <div class="custom-control custom-checkbox">
                                                <input class="custom-control-input" type="checkbox" id="rememberMe">
                                                <label class="custom-control-label" for="rememberMe">Remember Me</label>
                                            </div>
                                        </div>
                                        <div class="col-6 login-forgot-password">
                                            <a href="emp-pwd-forgot.php">Forgot Password?</a>
                                        </div>
                                    </div>

                                    <div class="form-group row login-submit">
                                        <div class="col-6">
                                            <input type="submit" name="emp_login" class="btn btn-success btn-xl" value="Log In">
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <!-- End Login -->
                        </div>
                    </div>
                    <div class="splash-footer"><a href="../index.php">Back to Home</a></div>
                    <div class="splash-footer">&copy; 2019 - <?php echo date('Y'); ?> Online Railway Reservation System | Developed by Kajal Gupta</div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/lib/jquery/jquery.min.js"></script>
    <script src="assets/lib/perfect-scrollbar/js/perfect-scrollbar.min.js"></script>
    <script src="assets/lib/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/app.js"></script>
    <script>
        $(document).ready(function () {
            App.init();
        });

        // JavaScript to Toggle Password Visibility
        function togglePassword(id) {
            var input = document.getElementById(id);
            if (input.type === "password") {
                input.type = "text";
            } else {
                input.type = "password";
            }
        }
    </script>
</body>
</html>
