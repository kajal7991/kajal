<!--Start Server side code to give us and hold session-->
<?php
  session_start();
  include('assets/inc/config.php');
  include('assets/inc/checklogin.php');
  check_login();
  $aid = $_SESSION['emp_id'];

  // Delete or remove library user PHP code
  if (isset($_GET['del'])) {
      $id = intval($_GET['del']); // Get the ID to delete
      
      // Prepare the delete query
      $adn = "DELETE FROM orrs_train WHERE id=?";
      $stmt = $mysqli->prepare($adn);
      
      // Check if prepare statement is successful
      if ($stmt) {
          $stmt->bind_param('i', $id); // Bind the parameter to the statement
          $stmt->execute(); // Execute the statement
          $stmt->close();
          
          // Check if deletion was successful
          if ($stmt->affected_rows > 0) {
              $succ = "Train Details Deleted Successfully!";
          } else {
              $err = "Deletion Failed! Please try again later.";
          }
      } else {
          $err = "Failed to prepare the SQL statement.";
      }
  }
?>
<!--End Server side scripting-->

<!DOCTYPE html>
<html lang="en">
<!-- HEAD -->
  <?php include('assets/inc/head.php');?>
  <!-- end HEAD --> 

  <body>
    <div class="be-wrapper be-fixed-sidebar">
      <!-- navbar -->
      <?php include('assets/inc/navbar.php');?>
      <!-- End navbar -->

      <!-- Sidebar -->
      <?php include('assets/inc/sidebar.php');?>
      <!-- End Sidebar -->

      <div class="be-content">
        <div class="page-head">
          <h2 class="page-head-title">Manage Tickets</h2>
          <nav aria-label="breadcrumb" role="navigation">
            <ol class="breadcrumb page-head-nav">
              <li class="breadcrumb-item"><a href="emp-dashboard.php">Dashboard</a></li>
              <li class="breadcrumb-item"><a href="#">Tickets</a></li>
              <li class="breadcrumb-item active">Manage Tickets</li>
            </ol>
          </nav>
        </div>

        <!-- Success or Error Alerts -->
        <?php if (isset($succ)) { ?>
          <script>
            setTimeout(function () { 
              swal("Success!", "<?php echo $succ; ?>", "success");
            }, 100);
          </script>
        <?php } ?>

        <?php if (isset($err)) { ?>
          <script>
            setTimeout(function () { 
              swal("Error!", "<?php echo $err; ?>", "error");
            }, 100);
          </script>
        <?php } ?>

        <div class="main-content container-fluid">
          <div class="row">
            <div class="col-sm-12">
              <div class="card card-table">
                <div class="card-header">Tickets</div>
                <div class="card-body">
                  <table class="table table-striped table-bordered table-hover table-fw-widget" id="table1">
                    <thead class="thead-dark">
                      <tr>
                        <th>Passenger</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Train Number</th>
                        <th>Departure</th>
                        <th>Arrival</th>
                        <th>Fare</th>
                        <th>Payment Code</th>
                        <th>Action</th>
                      </tr> 
                    </thead>
                    <tbody>
                    <?php
                        // Query to get details of available train tickets
                        $ret = "SELECT * FROM `orrs_train_tickets` "; 
                        $stmt = $mysqli->prepare($ret);
                        $stmt->execute();
                        $res = $stmt->get_result();
                        $cnt = 1;
                        while ($row = $res->fetch_object()) {
                    ?>
                      <tr>
                        <td><?php echo $row->pass_name; ?></td>
                        <td><?php echo $row->pass_email; ?></td>
                        <td><?php echo $row->pass_addr; ?></td>
                        <td><?php echo $row->train_no; ?></td>
                        <td class="center"><?php echo $row->train_dep_stat; ?></td>
                        <td class="center"><?php echo $row->train_arr_stat; ?></td>
                        <td class="center">₹<?php echo $row->train_fare; ?></td>
                        <td class="center"><?php echo $row->fare_payment_code; ?></td>
                        <td class="center">
                          <a class="badge badge-success" href="emp-confirm-tickets.php?ticket_id=<?php echo $row->ticket_id; ?>">Manage</a> 
                          <hr>
                          <a class="badge badge-danger" href="emp-manage-tickets.php?del=<?php echo $row->ticket_id; ?>">Delete</a>
                        </td>                      
                      </tr>
                    <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          <!-- Footer -->
          <?php include('assets/inc/footer.php');?>
          <!-- End Footer -->
        </div>
      </div>
    </div>

    <!-- JavaScript files -->
    <script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
    <script src="assets/lib/perfect-scrollbar/js/perfect-scrollbar.min.js" type="text/javascript"></script>
    <script src="assets/lib/bootstrap/dist/js/bootstrap.bundle.min.js" type="text/javascript"></script>
    <script src="assets/js/app.js" type="text/javascript"></script>
    <script src="assets/lib/datatables/datatables.net/js/jquery.dataTables.js" type="text/javascript"></script>
    <script src="assets/lib/datatables/datatables.net-bs4/js/dataTables.bootstrap4.js" type="text/javascript"></script>
    <script src="assets/lib/datatables/datatables.net-buttons/js/dataTables.buttons.min.js" type="text/javascript"></script>
    <script src="assets/lib/datatables/jszip/jszip.min.js" type="text/javascript"></script>
    <script src="assets/lib/datatables/pdfmake/pdfmake.min.js" type="text/javascript"></script>
    <script src="assets/lib/datatables/pdfmake/vfs_fonts.js" type="text/javascript"></script>
    <script src="assets/lib/datatables/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js" type="text/javascript"></script>
    <script src="assets/lib/datatables/datatables.net-responsive/js/dataTables.responsive.min.js" type="text/javascript"></script>
    <script src="assets/lib/datatables/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js" type="text/javascript"></script>

    <script type="text/javascript">
      $(document).ready(function() {
        // Initialize the JavaScript for table functionalities
        App.init();
        App.dataTables();
      });
    </script>
  </body>
</html>
