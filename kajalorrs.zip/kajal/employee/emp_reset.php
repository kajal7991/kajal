<?php
session_start();
include('assets/inc/config.php');

if (!isset($_SESSION['emp_id'])) {
    header("Location: pass-pwd-forgot.php"); // Redirect to request page if session is missing
    exit();
}

if (isset($_POST['update_pwd'])) {
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);
    $emp_id = $_SESSION['emp_id'];

    if ($new_password === $confirm_password) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        $query = "UPDATE orrs_employee SET emp_pwd = ? WHERE emp_id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('si', $hashed_password, $emp_id);

        if ($stmt->execute()) {
            session_destroy();
            header("Location: emp-login.php?msg=Password updated successfully. Please log in.");
            exit();
        } else {
            $err = "Error updating password. Please try again.";
        }
    } else {
        $err = "Passwords do not match. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="assets/css/app.css"/>
</head>
<body>
    <div class="be-wrapper be-login">
        <div class="be-content">
            <div class="splash-container forgot-password">
                <div class="card">
                    <div class="card-header">
                        <img class="logo-img" src="assets/img/logo-xx.png" alt="logo" width="102">
                        <span class="splash-description">Reset Your Password</span>
                    </div>
                    <div class="card-body">
                        <?php if(isset($err)) { ?>
                        <script>
                            setTimeout(function () { 
                                swal("Failed!", "<?php echo $err; ?>", "error");
                            }, 100);
                        </script>
                        <?php } ?>
                        <form method="POST">
                            <p>Enter your new password below.</p>
                            <div class="form-group pt-4">
                                <input class="form-control" type="password" name="new_password" required placeholder="New Password">
                            </div>
                            <div class="form-group pt-4">
                                <input class="form-control" type="password" name="confirm_password" required placeholder="Confirm Password">
                            </div>
                            <div class="form-group pt-1">
                                <input type="submit" name="update_pwd" class="btn btn-primary btn-block" value="Update Password">
                            </div>
                        </form>
                    </div>
                </div>
                <div class="splash-footer"><a href="emp-login.php">Home</a></div>
            </div>
        </div>
    </div>
    <script src="assets/lib/jquery/jquery.min.js"></script>
    <script src="assets/lib/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/swal.js"></script>
</body>
</html>
