<?php
session_start();
include('assets/inc/config.php');

$success = $err = "";

if (isset($_POST['pass_register'])) {
    $pass_fname = trim($_POST['pass_fname']);
    $pass_lname = trim($_POST['pass_lname']);
    $pass_phone = trim($_POST['pass_phone']);
    $pass_addr = trim($_POST['pass_addr']);
    $pass_uname = trim($_POST['pass_uname']);
    $pass_email = trim($_POST['pass_email']);
    $pass_pwd = $_POST['pass_pwd'];
    $pass_confirm_pwd = $_POST['pass_confirm_pwd'];

    // Check for empty fields
    if (empty($pass_fname) || empty($pass_lname) || empty($pass_phone) || empty($pass_addr) || empty($pass_uname) || empty($pass_email) || empty($pass_pwd) || empty($pass_confirm_pwd)) {
        $err = "All fields are required!";
    }
    // Validate names (only letters)
    elseif (!preg_match("/^[a-zA-Z]+$/", $pass_fname) || !preg_match("/^[a-zA-Z]+$/", $pass_lname)) {
        $err = "First and last names should contain only letters.";
    }
    // Validate phone (10 digits & unique)
    elseif (!preg_match("/^[0-9]{10}$/", $pass_phone)) {
        $err = "Phone number must be exactly 10 digits.";
    } else {
        $stmt = $mysqli->prepare("SELECT pass_phone FROM orrs_passenger WHERE pass_phone = ?");
        $stmt->bind_param('s', $pass_phone);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $err = "Phone number already registered.";
        } else {
            // Validate email (@gmail.com & must contain letters/numbers)
            if (!preg_match("/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d._%+-]+@gmail\.com$/", $pass_email)) {
                $err = "Enter a valid Gmail address with letters and numbers.";
            }
            // Validate password (min 8 chars, includes letters, numbers, and symbols)
            elseif (!preg_match("/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/", $pass_pwd)) {
                $err = "Password must be at least 8 characters, include a letter, number, and symbol.";
            }
            // Check if passwords match
            elseif ($pass_pwd !== $pass_confirm_pwd) {
                $err = "Passwords do not match!";
            } else {
                // Secure password hashing
                $hashed_pwd = password_hash($pass_pwd, PASSWORD_BCRYPT);

                // Insert into database
                $query = "INSERT INTO orrs_passenger (pass_fname, pass_lname, pass_phone, pass_addr, pass_uname, pass_email, pass_pwd) VALUES(?,?,?,?,?,?,?)";
                $stmt = $mysqli->prepare($query);
                $stmt->bind_param('sssssss', $pass_fname, $pass_lname, $pass_phone, $pass_addr, $pass_uname, $pass_email, $hashed_pwd);

                if ($stmt->execute()) {
                    $success = "Account successfully created! Proceed to Log In.";
                } else {
                    $err = "Error: Please try again later.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passenger Signup | Online Railway Reservation System</title>
    <link rel="stylesheet" href="assets/css/app.css">
    <style>
        .message { padding: 10px; margin-bottom: 15px; border-radius: 5px; display: none; }
        .error-msg { background-color: #ffdddd; color: red; }
        .success-msg { background-color: #ddffdd; color: green; }
        .toggle-password { position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer; }
    </style>
</head>

<body class="be-splash-screen">
    <div class="be-wrapper be-login">
        <div class="be-content">
            <div class="main-content container-fluid">
                <div class="splash-container">
                    <div class="card card-border-color card-border-color-success">
                        <div class="card-header">
                            <img class="logo-img" src="assets/img/logo-xx.png" alt="logo" width="100" height="27">
                            <span class="splash-description">Passenger Registration Form</span>
                        </div>
                        <div class="card-body">
                            <!-- Success & Error Messages -->
                            <?php if ($success) { echo "<div class='message success-msg'>$success</div>"; } ?>
                            <?php if ($err) { echo "<div class='message error-msg'>$err</div>"; } ?>

                            <!-- Registration Form -->
                            <form method="POST">
                                <div class="login-form">
                                    <div class="form-group">
                                        <input class="form-control" name="pass_fname" type="text" placeholder="First Name" required pattern="[A-Za-z]+" title="Only letters allowed">
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" name="pass_lname" type="text" placeholder="Last Name" required pattern="[A-Za-z]+" title="Only letters allowed">
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" name="pass_phone" type="text" placeholder="Phone Number" required pattern="[0-9]{10}" title="Enter a valid 10-digit phone number">
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" name="pass_addr" type="text" placeholder="Address" required>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" name="pass_uname" type="text" placeholder="Username" required>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" name="pass_email" type="email" placeholder="Email Address" required>
                                    </div>
                                    <div class="form-group" style="position: relative;">
                                        <input class="form-control" name="pass_pwd" id="pass_pwd" type="password" placeholder="Password" required>
                                        <span class="toggle-password" onclick="togglePassword('pass_pwd')">👁️‍🗨️</span>
                                    </div>
                                    <div class="form-group" style="position: relative;">
                                        <input class="form-control" name="pass_confirm_pwd" id="pass_confirm_pwd" type="password" placeholder="Confirm Password" required>
                                        <span class="toggle-password" onclick="togglePassword('pass_confirm_pwd')">👁️‍🗨️</span>
                                    </div>
                                    <div class="form-group row login-submit">
                                        <div class="col-6"><a class="btn btn-outline-success btn-xl" href="pass-login.php">Login</a></div>
                                        <div class="col-6"><input type="submit" name="pass_register" class="btn btn-outline-danger btn-xl" value="Register"></div>
                                    </div>
                                </div>
                            </form>
                            <!-- End Registration Form -->
                        </div>
                    </div>
                    <div class="splash-footer">&copy; 2024 - <?php echo date('Y'); ?> Online Railway Reservation System | Developed By Kajal Gupta</div>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript to Toggle Password Visibility -->
    <script>
        function togglePassword(id) {
            var input = document.getElementById(id);
            input.type = input.type === "password" ? "text" : "password";
        }

        // Show messages
        document.addEventListener("DOMContentLoaded", function () {
            var messages = document.querySelectorAll(".message");
            messages.forEach(function (msg) {
                if (msg.textContent.trim() !== "") {
                    msg.style.display = "block";
                }
            });
        });
    </script>
</body>
</html>
