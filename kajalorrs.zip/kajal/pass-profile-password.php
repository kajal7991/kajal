<?php
session_start();
include('assets/inc/config.php');
include('assets/inc/checklogin.php');
check_login();

$aid = $_SESSION['pass_id'];
$success = $error = "";

if (isset($_POST['Update_Password'])) {
    $old_pass = $_POST['old_pass'];
    $new_pass = $_POST['pass_pwd'];
    $confirm_pass = $_POST['confirm_pass_pwd'];

    // Fetch stored hashed password
    $query = "SELECT pass_pwd FROM orrs_passenger WHERE pass_id=?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('i', $aid);
    $stmt->execute();
    $stmt->bind_result($db_pass);
    $stmt->fetch();
    $stmt->close();

    if (!$db_pass) {
        $error = "User not found.";
    } elseif (!password_verify($old_pass, $db_pass)) {
        $error = "Old password is incorrect.";
    } elseif ($new_pass !== $confirm_pass) {
        $error = "New passwords do not match.";
    } elseif (!preg_match("/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/", $new_pass)) {
        $error = "New password must be at least 8 characters, include a letter, number, and symbol.";
    } else {
        // Hash new password
        $hashed_pwd = password_hash($new_pass, PASSWORD_BCRYPT);

        // Update password
        $update_query = "UPDATE orrs_passenger SET pass_pwd = ? WHERE pass_id = ?";
        $stmt = $mysqli->prepare($update_query);
        $stmt->bind_param('si', $hashed_pwd, $aid);
        
        if ($stmt->execute()) {
            $success = "Password updated successfully!";
        } else {
            $error = "Error updating password. Please try again.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('assets/inc/head.php'); ?>
</head>
<body>
<div class="be-wrapper be-fixed-sidebar">
    
    <!-- Navbar -->
    <?php include('assets/inc/navbar.php'); ?>
    <!-- Sidebar -->
    <?php include('assets/inc/sidebar.php'); ?>

    <div class="be-content">
        <div class="page-head">
            <h2 class="page-head-title">Change Password</h2>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb page-head-nav">
                    <li class="breadcrumb-item"><a href="pass-dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="#">Profile</a></li>
                    <li class="breadcrumb-item active">Change Password</li>
                </ol>
            </nav>
        </div>

        <!-- Display Success & Error Messages -->
        <?php if ($success) { ?>
            <script>setTimeout(() => { swal("Success!", "<?php echo $success; ?>", "success"); }, 100);</script>
        <?php } ?>
        <?php if ($error) { ?>
            <script>setTimeout(() => { swal("Failed!", "<?php echo $error; ?>", "error"); }, 100);</script>
        <?php } ?>

        <div class="main-content container-fluid">
            <div class="col-md-12">
                <div class="card card-border-color card-border-color-success">
                    <div class="card-header">Change Password <span class="card-subtitle">Fill all details</span></div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Old Password</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input class="form-control" name="old_pass" id="oldPassword" type="password" required>
                                    <span class="toggle-password" onclick="togglePassword('oldPassword')" style="position: absolute; right: 30px; top: 50%; transform: translateY(-50%); cursor: pointer;">👁️‍🗨️</span>

                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">New Password</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input class="form-control" name="pass_pwd" id="newPassword" type="password" required>
                                    <span class="toggle-password" onclick="togglePassword('newPassword')" style="position: absolute; right: 30px; top: 50%; transform: translateY(-50%); cursor: pointer;">👁️‍🗨️</span>

                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-12 col-sm-3 col-form-label text-sm-right">Confirm New Password</label>
                                <div class="col-12 col-sm-8 col-lg-6">
                                    <input class="form-control" name="confirm_pass_pwd" id="confirmNewPassword" type="password" required>
                                    <span class="toggle-password" onclick="togglePassword('confirmNewPassword')" style="position: absolute; right: 30px; top: 50%; transform: translateY(-50%); cursor: pointer;">👁️‍🗨️</span>

                                </div>
                            </div>

                            <div class="col-sm-6">
                                <p class="text-right">
                                    <input class="btn btn-space btn-success" value="Change Password" name="Update_Password" type="submit">
                                    <button class="btn btn-space btn-danger" type="reset">Cancel</button>
                                </p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>    

    <?php include('assets/inc/footer.php'); ?>
</div>

<!-- Scripts - Ensure Proper Loading -->
<script src="assets/lib/jquery/jquery.min.js"></script>
<script src="assets/lib/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>

<script>
    $(document).ready(function() {
        App.init();  // Initialize App
        App.formElements();  // Ensure Form Elements are Initialized

        // Debugging Click Event on Sidebar
        $('.be-left-sidebar').on('click', function(event) {
            console.log("Sidebar Clicked!", event.target);
        });

        // Fix Sidebar Not Clickable Issue
        $('.be-left-sidebar').css("pointer-events", "auto");
    });
</script>

<script>
    function togglePassword(id) {
        var input = document.getElementById(id);
        input.type = (input.type === "password") ? "text" : "password";
    }
</script>


</body>
</html>
