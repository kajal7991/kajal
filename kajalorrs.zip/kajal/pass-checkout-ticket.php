<?php
session_start();
include('assets/inc/config.php');
include('assets/inc/checklogin.php');
check_login();
$aid = $_SESSION['pass_id'];

if (isset($_POST['train_fare_checkout'])) {
    $pass_fare_payment_code = $_POST['pass_fare_payment_code'];

    // Update the fare payment code in the database
    $query = "UPDATE orrs_passenger SET pass_fare_payment_code = ? WHERE pass_id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('si', $pass_fare_payment_code, $aid);
    $stmt->execute();

    if ($stmt) {
        $succ = "Ticket Paid! Redirecting to Payment Confirmation...";
    } else {
        $err = "Payment Failed! Please Try Again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include('assets/inc/head.php'); ?>
<!-- End Head -->

<body>
    <div class="be-wrapper be-fixed-sidebar">
        <!-- Navigation Bar -->
        <?php include('assets/inc/navbar.php'); ?>
        <!-- End Navigation Bar -->

        <!-- Sidebar -->
        <?php include('assets/inc/sidebar.php'); ?>
        <!-- End Sidebar -->

        <div class="be-content">
            <div class="page-head">
                <h2 class="page-head-title">Train Ticket Checkout</h2>
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb page-head-nav">
                        <li class="breadcrumb-item"><a href="pass-dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="#">Tickets</a></li>
                        <li class="breadcrumb-item"><a href="#">Checkout</a></li>
                    </ol>
                </nav>
            </div>

            <?php if (isset($succ)) { ?>
                <script>
                    setTimeout(function() {
                        swal({
                            title: "Success!",
                            text: "<?php echo $succ; ?>",
                            icon: "success"
                        }).then(function() {
                            window.location.href = "pass-confirm-ticket.php";
                        });
                    }, 100);
                </script>
            <?php } ?>

            <?php if (isset($err)) { ?>
                <script>
                    setTimeout(function() {
                        swal("Failed!", "<?php echo $err; ?>", "error");
                    }, 100);
                </script>
            <?php } ?>

            <div class="main-content container-fluid">
                <?php
                $aid = $_SESSION['pass_id'];
                $ret = "SELECT * FROM orrs_passenger WHERE pass_id = ?";
                $stmt = $mysqli->prepare($ret);
                $stmt->bind_param('i', $aid);
                $stmt->execute();
                $res = $stmt->get_result();

                while ($row = $res->fetch_object()) {
                ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card card-border-color card-border-color-success">
                                <div class="card-header card-header-divider">
                                    <span class="card-subtitle">Fill All Details</span>
                                </div>
                                <div class="card-body">
                                    <form method="POST">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">First Name</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input class="form-control" readonly value="<?php echo $row->pass_fname; ?>" type="text">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Last Name</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input class="form-control" readonly value="<?php echo $row->pass_lname; ?>" type="text">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Phone Number</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input class="form-control" readonly value="<?php echo $row->pass_phone; ?>" type="text">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Address</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input class="form-control" readonly value="<?php echo $row->pass_addr; ?>" type="text">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Booked Train Number</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input class="form-control" readonly value="<?php echo $row->pass_train_number; ?>" type="text">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Booked Train Name</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input class="form-control" readonly value="<?php echo $row->pass_train_name; ?>" type="text">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Departure</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input class="form-control" readonly value="<?php echo $row->pass_dep_station; ?>" type="text">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Arrival</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input class="form-control" readonly value="<?php echo $row->pass_arr_station; ?>" type="text">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Train Fare</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input class="form-control" readonly value="<?php echo $row->pass_train_fare; ?>" type="text">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Payment Code</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input class="form-control" name="pass_fare_payment_code" value="<?php echo $row->pass_fare_payment_code; ?>" type="text" required>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <p class="text-right">
                                                <input class="btn btn-space btn-success" value="Checkout" name="train_fare_checkout" type="submit">
                                                <button class="btn btn-space btn-danger">Cancel</button>
                                            </p>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>

            <!-- Footer -->
            <?php include('assets/inc/footer.php'); ?>
            <!-- End Footer -->
        </div>
    </div>

    <script src="assets/lib/jquery/jquery.min.js"></script>
    <script src="assets/lib/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/app.js"></script>
</body>

</html>
